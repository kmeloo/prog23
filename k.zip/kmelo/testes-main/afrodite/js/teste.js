function abrir() {
    

    window.location.href = "confirmar.html";
}
