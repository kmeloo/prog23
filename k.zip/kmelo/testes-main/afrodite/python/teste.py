from loja import *
# Exemplo de uso:
produto1 = Produto(descricao = "Top preto", situacao = "SITUAÇAO: SEMINOVO", cor ="PRETO", nome_imagem="imgs/blusa1fem.jpg")
produto2 = Produto(descricao = "Regata Esportiva", situacao = "SITUAÇAO: SEMINOVO", cor ="Branca", nome_imagem="imgs/blusa2fem.jpg")

with app.app_context():
    db.create_all()
    db.session.add(produto1)
    db.session.add(produto2)
    db.session.commit()
    print(produto1)
    print(produto1.json())

