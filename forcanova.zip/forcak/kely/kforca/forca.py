
import os,pygame, sqlite3
from pygame.locals import *
import funcionalidades_forca



blue = (0,0,255)
WINDOW_WIDTH  = 1300
WINDOW_HEIGHT = 750
#letra_camuflada_fonte = pygame.font.SysFont("Courier New", 35).render('_', 1, (0,0,0)) # WINDOW.blit(letra_camuflada_fonte , (200, 500))

# funcao definida para exibir mensagem na tela
def show_text( msg, color, x=WINDOW_WIDTH//2, y=WINDOW_WIDTH//2 ):
    global WINDOW
    text = font.render( msg, True, color)
    WINDOW.blit(text, ( x, y ) )

def adicionarMembros():
    imagem = pygame.image.load(os.path.abspath("kely/kforca/pau.png"))
    if chances == chances//8:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/cabeza.png"))
    if chances == chances//7:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/tronco.png"))
    if chances == chances//6:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/bracodireito.png"))
    if chances == chances//5:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/bracoesquerdo.png"))
    if chances == chances//4:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/bracodireito.png"))
    if chances == chances//3:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/pernaesq.png"))
    if chances == chances//2:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/pernadir.png"))
    if chances == 1:
        imagem = pygame.image.load(os.path.abspath("kely/kforca/morte.png"))
    return imagem


pygame.init()

clock = pygame.time.Clock()

WINDOW = pygame.display.set_mode((WINDOW_WIDTH,WINDOW_HEIGHT))
pygame.display.set_caption("Text") # posicao forca:208 620

# criar a fonte (eh feito so uma vez)
font = pygame.font.SysFont(None, 80)
palavra = funcionalidades_forca.escolherPalavraDoDicionario()
chances = len(palavra)
mascara = funcionalidades_forca.disfarcarPalavra(palavra)
letras_tentadas = funcionalidades_forca.letras_tentadas

print(palavra)
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            exit()

        if event.type == pygame.KEYDOWN:
            letra = str(pygame.key.name(event.key))
            if letra not in palavra:
                    chances -= 1
                    letras_tentadas.append(letra)
                    print('errou')
            else:
                index = 0
                for letraDaPalavra in palavra:
                    if index > len(palavra):
                            index = -1
                    if letraDaPalavra == letra:
                            mascara[index] = letra
                    index +=1
        if mascara.count('_') == 0:
            print('Parabéns! Você ganhou! =D')
            con = sqlite3.connect("palavrasAcertadas.db")
            cur = con.cursor()
            cur.execute(f"INSERT INTO palavra_acertadas (palavra) VALUES ({palavra});")
            con.commit()
            
            
            
            con.close()

            exit()

    WINDOW.fill( ( 255, 255, 255 ) )   # fill screen with white background

    # converte a palavra para mostrar
    comoEstaFicando = ''
    for elemento in mascara:
        comoEstaFicando += ' '
        comoEstaFicando += elemento
    show_text(comoEstaFicando, (0,0,0))
    forca = adicionarMembros()
    WINDOW.blit(forca, (0, 0))

    

    pygame.display.update()
    clock.tick(60)
