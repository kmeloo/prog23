
import time
import pygame
from pygame.locals import *

blue = (0,0,255)
WINDOW_WIDTH  = 1300
WINDOW_HEIGHT = 750

# funcao definida para exibir mensagem na tela
def show_text( msg, color, x=WINDOW_WIDTH//2, y=WINDOW_WIDTH//2 ):
    global WINDOW
    text = font.render( msg, True, color)
    WINDOW.blit(text, ( x, y ) )

pygame.init()

clock = pygame.time.Clock()

WINDOW = pygame.display.set_mode((WINDOW_WIDTH,WINDOW_HEIGHT))
pygame.display.set_caption("Text") # posicao forca:208 620

# criar a fonte (eh feito so uma vez)
font = pygame.font.SysFont(None, 25)

while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            exit()
        print(pygame.mouse.get_pos())

    WINDOW.fill( ( 255, 255, 255 ) )   # fill screen with white background
    p = pygame.image.load('kforca/morte.jpg')
    WINDOW.blit(p, (0, 0))
    

    pygame.display.update()
    clock.tick(60)
