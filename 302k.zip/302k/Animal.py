from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os

# configurações
app = Flask(__name__)
path = os.path.dirname(os.path.abspath(__file__))
arquivobd = os.path.join(path, 'profissoes.db')
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///"+arquivobd
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 
db = SQLAlchemy(app)

class Animal(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    nome = db.Column(db.Text)
    raca = db.Column(db.Text)
    cor = db.Column(db.Text)
    genero = db.Column(db.Text)
    dtnasc = db.Column (db.Text)
    tipo = db.Column(db.Text) 
    __mapper_args__ = {
        'polymorphic_identity':'animal',
        'polymorphic_on': tipo
}
    def __str__(self):
        return f'{self.nome}, {self.raca}, {self.cor},  {self.genero}'

class Gato (Animal):
    id = db.Column(db.Integer, db.ForeignKey('animal.id') , primary_key = True)
    fugas = db.Column(db.Integer)
    __mapper_args__ = {
    'polymorphic_identity' : "Gato"
    }
    def __str__(self):
        return super().__str__() + f", fugas = {self.fugas}"


class Cachorro (Animal):
    id = db.Column(db.Integer , db.ForeignKey('animal.id'), primary_key = True)
    __mapper_args__ = {
    'polymorphic_identity' : "Cachorro"
    }
    def __str__(self):
        return super().__str__()
    
with app.app_context():

    # início do programa de testes
    if os.path.exists(arquivobd): # se o arquivo já existe...
        os.remove(arquivobd) # o arquivo é removido

    db.create_all() # criar as tabelas no banco

    g1 = Gato(nome = "Merlim",
    raca = "Persa",
    cor = "preto",
    genero = 'F',
    dtnasc = "24/05/2005",
    fugas = 50
    )

    c1 = Cachorro(nome = "Bilu",
    raca = "Vira-lata",
    cor = "Caramelo",
    genero = "M",
    dtnasc = "22/05/2005"
    )

    db.session.add(g1)
    db.session.add(c1)
    db.session.commit()

    print(g1, c1)